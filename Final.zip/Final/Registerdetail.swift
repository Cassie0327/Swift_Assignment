//
//  Registerdetail.swift
//  Final
//
//  Created by 蔡倩 on 12/14/19.
//  Copyright © 2019 Qian Cai. All rights reserved.
//

import UIKit

class Registerdetail: UIViewController {

    @IBOutlet weak var text: UITextView!
    var label:String?
    var c1:course!
    var isseat=true
    let s=UserDefaults().string(forKey: "userName") ?? ""
    override func viewDidLoad() {
        super.viewDidLoad()
        text.text=label

        // Do any additional setup after loading the view.
    }
    @IBAction func regis(_ sender: UIButton) {
        
        for one in studentlist
        {
            
            if(one.account==s)
            {
                for n in one.wait_c
                {       var i=0
                    if(c1.course_name==n.course_name)
                    {
                        if (c1.seat_max-c1.seat>=0)
                        {
                            one.wait_c.remove(at: i)
                            one.seat_c.append(c1)

                            let alertController = UIAlertController(title: "Alert", message: "Register Successfully!", preferredStyle: UIAlertController.Style.alert)
                            let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) {
                                (result : UIAlertAction) -> Void in
                             print("OK")
                            }
                               alertController.addAction(okAction)
                             self.present(alertController, animated: true, completion: nil)
                                return
                            
                            
                            
                            
                        }
                        else
                        {
                            let alertController = UIAlertController(title: "Alert", message: "Seat is full!", preferredStyle: UIAlertController.Style.alert)
                            let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) {
                                (result : UIAlertAction) -> Void in
                             print("OK")
                            }
                               alertController.addAction(okAction)
                             self.present(alertController, animated: true, completion: nil)
                                return
                            
                            
                        }
                        
                        i=i+1
                    }
                  
                }
            
        }
        
    
        }}
    @IBAction func remove(_ sender: UIButton) {
        
        
        for one in studentlist
        {
            if(one.account==s)
            {     var i=0
                for n in one.seat_c
                {
                    if(c1.course_name==n.course_name)
                    {
                        one.seat_c.remove(at: i)
                        let alertController = UIAlertController(title: "Alert", message: "Remove Successfully!", preferredStyle: UIAlertController.Style.alert)
                                               let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) {
                                                   (result : UIAlertAction) -> Void in
                                                print("OK")
                                               }
                                                  alertController.addAction(okAction)
                                                self.present(alertController, animated: true, completion: nil)
                                                   return
                        
                    }
                    
                    i=i+1
                }
                for n in one.wait_c
                {
                    if(c1.course_name==n.course_name)
                    {
                        one.wait_c.remove(at: i)
                        let alertController = UIAlertController(title: "Alert", message: "Remove Successfully!", preferredStyle: UIAlertController.Style.alert)
                        let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) {
                            (result : UIAlertAction) -> Void in
                         print("OK")
                        }
                           alertController.addAction(okAction)
                         self.present(alertController, animated: true, completion: nil)
                            return
                        
                    }
                    
                    i=i+1
                }
            }
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
