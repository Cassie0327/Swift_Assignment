//
//  registerd.swift
//  Final
//
//  Created by 蔡倩 on 12/14/19.
//  Copyright © 2019 Qian Cai. All rights reserved.
//

import UIKit

class registerd: UIViewController {
    var label:String?
    var c1:course!
let s=UserDefaults().string(forKey: "userName") ?? ""
    @IBOutlet weak var text: UITextView!
    var h1=true
    var h2=true
    var h3=true
    var h4=false
    override func viewDidLoad() {
        super.viewDidLoad()
        text.text = label
        // Do any additional setup after loading the view.
    }
    @IBAction func add(_ sender: UIButton) {
        for one in studentlist
        {
            if (one.account==s)
            {
                for n1 in one.time
                {
                    if (n1==c1.time)
                    {
                        h1=false
                        //alert-conflict
                        
                        let alertController = UIAlertController(title: "Alert", message: "Time conflict!", preferredStyle: UIAlertController.Style.alert)
                                 let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) {
                                (result : UIAlertAction) -> Void in
                                   print("OK")
                        }
                               alertController.addAction(okAction)
                              self.present(alertController, animated: true, completion: nil)
                        
                        
                        
                    }
                    
                }
                for n2 in one.seat_c
                {
                    if(n2.course_name==c1.course_name)
                    {
                        h2=false
                        //alert-already
                        let alertController = UIAlertController(title: "Alert", message: "The course is already in your seatlist!", preferredStyle: UIAlertController.Style.alert)
                        let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) {
                            (result : UIAlertAction) -> Void in
                         print("OK")
                        }
                           alertController.addAction(okAction)
                         self.present(alertController, animated: true, completion: nil)
                            return
                        
                        
                        
                        
                    }
                }
                for n3 in one.wait_c
                              {
                                  if(n3.course_name==c1.course_name)
                                  {
                                      h3=false
                                      //alert-already waitlist
                                    let alertController = UIAlertController(title: "Alert", message: "The course is already in your wailtist!", preferredStyle: UIAlertController.Style.alert)
                                                           let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) {
                                                               (result : UIAlertAction) -> Void in
                                                            print("OK")
                                                           }
                                                              alertController.addAction(okAction)
                                                            self.present(alertController, animated: true, completion: nil)
                                                               return
                                    
                                    
                                    
                                    
                                    
                                  }
                              }
                if(one.major==c1.subject)
                {
                    h4=true
                }
                else
                {
                    let alertController = UIAlertController(title: "Alert", message: "You are not belong to this subject", preferredStyle: UIAlertController.Style.alert)
                    let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) {
                        (result : UIAlertAction) -> Void in
                     print("OK")
                    }
                       alertController.addAction(okAction)
                     self.present(alertController, animated: true, completion: nil)

                }
                
                if (h1 && h2 && h3 && h4)
                {
                if(c1.seat<=c1.seat_max)
                {//seat is not filled
                    one.seat_c.append(c1)
                    one.time.append(c1.time)
                    c1.seat=c1.seat+1
                    
                    let alertController = UIAlertController(title: "Alert", message: "You register it sucessfully!", preferredStyle: UIAlertController.Style.alert)
                    let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) {
                        (result : UIAlertAction) -> Void in
                     print("OK")
                    }
                       alertController.addAction(okAction)
                     self.present(alertController, animated: true, completion: nil)
                    
                    
                    
                    
                    
                    
                }
                else{
                    //seat is filled
                    if(c1.wait<=c1.waitlist_max)
                    {
                        one.wait_c.append(c1)
                        c1.wait=c1.wait+1
                        
                        
                        let alertController = UIAlertController(title: "Alert", message: "You are already in waitlist sucessfully!", preferredStyle: UIAlertController.Style.alert)
                            let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) {
                                (result : UIAlertAction) -> Void in
                             print("OK")
                            }
                               alertController.addAction(okAction)
                             self.present(alertController, animated: true, completion: nil)
                            
                            
        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    }
                    else{
                        //alert- both filled
                        let alertController = UIAlertController(title: "Alert", message: "The seat and waitlist are both full", preferredStyle: UIAlertController.Style.alert)
                        let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) {
                            (result : UIAlertAction) -> Void in
                         print("OK")
                        }
                           alertController.addAction(okAction)
                         self.present(alertController, animated: true, completion: nil)
                        
                        
                    }
                    
                }
                }
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
            }
            }

    
    
    
    
    
    
    
    
    
    
    
    }
}
