//
//  coursed.swift
//  Final
//
//  Created by 蔡倩 on 12/14/19.
//  Copyright © 2019 Qian Cai. All rights reserved.
//

import UIKit

class coursed: UIViewController {
    @IBOutlet weak var text: UITextView!
    var label:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        text.text=label

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
