//
//  Register_s.swift
//  Final
//
//  Created by 蔡倩 on 12/14/19.
//  Copyright © 2019 Qian Cai. All rights reserved.
//

import UIKit

class Register_s: UIViewController {

    @IBOutlet weak var keyword: UITextField!
    @IBOutlet weak var subject: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    
       
            guard let id=segue.identifier else{return}
             if id=="search2"
               {
               
            if let vcd2=segue.destination as? Register_de
               {
                vcd2.sub=subject.text
                vcd2.name=keyword.text
              
                  
             
                   
               
        }
        }}

}
