//
//  Infomation.swift
//  Final
//
//  Created by 蔡倩 on 12/12/19.
//  Copyright © 2019 Qian Cai. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class course
{
    var course_id:String
    var course_name:String
    var seat_max=40
    var waitlist_max=10
    var seat:Int
    var wait:Int
    var instructor:String
    var subject:String
    var hour:Int
    var time:String
    var position:String
    var course_description:String
    init(course_id:String,course_name:String,seat:Int,wait:Int,instructor:String,subject:String,hour:Int,time:String,position:String,course_description:String)
    {
        self.course_id=course_id
        self.course_name=course_name
        self.seat=seat
        self.wait=wait
        self.instructor=instructor
        self.subject=subject
        self.hour=hour
        self.time=time
        self.position=position
        self.course_description=course_description
    }
}
class student
{
    var account:String
    var major:String
    var password:String
    var student_credit:Int
    var student_name:String
    var student_id:String
    var seat_c:[course]
    var wait_c:[course]
    var time:[String]
    init(account:String,major:String,password:String,student_credit:Int,student_name:String,student_id:String,seat_c:[course],wait_c:[course],time:[String])
    {
        self.account=account
        self.major=major
        self.password=password
        self.student_id=student_id
        self.student_name=student_name
        self.student_credit=student_credit
        self.seat_c=seat_c
        self.wait_c=wait_c
        self.time=time
      
    }
   
    
}
    var courselist:[course]=[course]()


    var studentlist:[student]=[student]()



func begin()
{

    let c1=course(course_id:"6205",course_name:"Program Structure and Algorithms",seat:20,wait: 10,instructor:"Ghassemi,Mohsen",subject:"Infomation system engineering",hour:4,time:"Monday 18:00-22:00",position:"225 Terry Ave | Room 307",course_description:"Presents data structures and related algorithms, beginning with a brief review of dynamic memory allocation. Discusses the fundamental data structures in detail, including the abstract representation, supporting algorithms, and implementation methods. Focuses on understanding the application of the abstract data structure and the circumstances that affect implementation decisions. Covers lists, stacks, queues, trees, hash tables, and graphs. Covers recursion and searching and sorting algorithms in detail. Emphasizes data abstraction and encapsulation in code design. Explores external storage structures, time permitting.")
    let c2=course(course_id:"6350",course_name:"Smartphones-Based Web Development",seat:23,wait: 10,instructor:"Ahmed,Rabah",subject:"Infomation system engineering",hour:4,time:"Wednesday 1:00-4:00",position:"Richards Hall | Room 236",course_description:"Covers application development for mobile devices using advanced development platforms. Focuses on how to write mobile applications using cross-platform development tools and processes. Topics include user interfaces, the software life cycle, persistent storage, networking using HTTP and other REST interfaces, and mobile/handheld data applications. Requires a final project."
    )

    
    let c3=course(course_id:"6105",course_name:"Data Science Engineering Methods and Tools",seat:25,wait: 10,instructor:"Liu,Handan",subject:"Infomation system engineering",hour:4,time:"Tuesday 9:00-13:00",position:"Behrakis Health Sciences Cntr | Room 315",course_description:"Introduces the fundamental techniques for machine learning and data science engineering. Discusses a variety of machine learning algorithms, along with examples of their implementation, evaluation, and best practices. Lays the foundation of how learning models are derived from complex data pipelines, both algorithmically and practically. Topics include supervised learning (parametric/nonparametric algorithms, support vector machines, kernels, neural networks, deep learning) and unsupervised learning (clustering, dimensionality reduction, recommender systems). Based on numerous real-world case studies.")
    
    let c4=course(course_id:"6255",course_name:"Software Quality Control and Management",seat:30,wait: 8,instructor:"Servattalab,Matthew ",subject:"Infomation system engineering",hour:4,time:"Tuesday 10:00-14:00",position:"Knowles Center | Room 002B",course_description:"Examines techniques for the management and evolution of software systems. Topics include managing software as an asset; life cycle development and rapid development technologies; maintainability; quality assurance of software systems including testing strategies and problem analysis; software risk analysis; analysis of software project failures; process models, such as CMM and ISO 9001; configuration management; and the impact of new development technologies on software management."
     )
    
    let c5=course(course_id:"6250",course_name:"Web Development Tools and Methods",seat:29,wait: 10,instructor:"Ritter,Brett",subject:"Infomation system engineering",hour:4,time:"Friday 18:00-22:00",position:"Behrakis Health Sciences | Room 325",course_description:"Introduces object-oriented design and programming via the Java programming language; the use of inheritance, composition, and interface classes in software design; development of Java applets and applications; study of the Java class libraries, including the swing tool kit for building human computer interfaces, the network package for development of client-server systems, and the collections&#8217; package for data structures and sorting algorithms. Requires a course project. Requires knowledge of C programming.")
    
    let c6=course(course_id:"6200",course_name:"Concepts of Object-Oriented Design",seat:28,wait: 10,instructor:"Munson,Mark",subject:"Computer system engineering",hour:4,time:"Saturday 18:00-22:00",position:"Behrakis Health Sciences | Room 325", course_description: "Introduces object-oriented design and programming via the Java programming language; the use of inheritance, composition, and interface classes in software design; development of Java applets and applications; study of the Java class libraries, including the swing tool kit for building human computer interfaces, the network package for development of client-server systems, and the collections&#8217; package for data structures and sorting algorithms. Requires a course project. Requires knowledge of C programming.")
 
    
    let c7=course(course_id:"6225",course_name:"Network Structures and Cloud Computing",seat:26,wait: 10,instructor:"Ghassemi,Mohsen",subject:"Computer system engineering",hour:4,time:"Saturday 18:00-22:00",position:"225 Terry Ave | Room 402",course_description:"Offers a practical foundation in cloud computing and hands-on experience with the tools used in cloud computing. Designed as a foundation course for cloud-aware, adept professionals. Focuses on the fundamentals of cloud computing, the principal areas of cloud architectures, cloud security, cloud governance, cloud storage, cloud virtualization, and cloud capacity. Discusses the Internet evolution that led to cloud and how cloud applications revolutionized Web applications.")
    
    
    let c8=course(course_id:"7200",course_name:"Big-Data System Engineering Using Scala",seat:20,wait: 10,instructor:"Hillyard, Robin",subject:"Computer system engineering",hour:4,time:"Sunday 18:00-22:00",position:"West Village H | Room 108",course_description:"Covers the fundamentals of functional programming with Scala and seeks to provide a basic, practical foundation for students who want to use it as a language for working with big-data platforms. Scala is one of a new breed of general-purpose functional programming languages that is strongly typed and is object oriented. It runs on the Java virtual machine and is able to share libraries from the vast collection of open-source projects written in Java. For these reasons it is readily accessible by programmers of Java, C++, and similar languages.")
    
    let c9=course(course_id:"6350",course_name:"Deployment and Operation of Software Applications",seat:30,wait: 6,instructor:"Konstantopoulos, Constantin",subject:"Computer system engineering",hour:4,time:"Thursday 11:00-25:00",position: "Behrakis Health Sciences Cntr | Room 320",course_description:"Introduces the four most popular infrastructure languages—Chef, Puppet, Ansible, and Salt— and codes with them in the same way that we code with Java, Python, C#, and Javascript. IT infrastructure languages and their underlying methods and tools, referred to as DevOps, bridge the gap between software development and software administration. Instead of recruiting CPU cycles on our laptops, we create and manage virtual IT infrastructures on a public cloud. Offers students an opportunity to learn how to manipulate virtual machines, containers, and lambdas and set up assembly lines on public clouds in the fashion of a Model T assembly line.")
    
    
 let s1=student(account:"cai.qian",major:"Computer system engineering",password:"cq960327",student_credit:4,student_name:"Qian Cai",student_id:"1389278",seat_c: [],wait_c: [],time:[])
    let s2=student(account:"cassie",major:"Infomation system engineering",password:"cassie001",student_credit:4,student_name:"Cassie",student_id:"1389275",seat_c: [],wait_c: [],time:[])
       
    courselist.append(c1)
    courselist.append(c2)
    courselist.append(c3)
    courselist.append(c4)
    courselist.append(c5)
    courselist.append(c6)
    courselist.append(c7)
    courselist.append(c8)
    courselist.append(c9)
    studentlist.append(s1)
    studentlist.append(s2)
  
  
   
    
}
func begin1()
{
    
}
