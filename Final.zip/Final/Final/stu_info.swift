//
//  stu_info.swift
//  Final
//
//  Created by 蔡倩 on 12/13/19.
//  Copyright © 2019 Qian Cai. All rights reserved.
//

import UIKit
import CoreData
class stu_info: UIViewController {

    @IBOutlet weak var text: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    let s=UserDefaults().string(forKey: "userName") ?? ""
            
        var str:String?
           
               for two in studentlist
                {
                  if(two.account==s)
                        {
                    str="student id: \(two.student_id)"+"\n"+"\n"+"student name: \(two.student_name) "+"\n"+"\n"+"student account: \(two.account) "+"\n"+"\n"+"password: \(two.password)"+"\n"+"\n"+"student major:\(two.major)"
                    
                        }
                       
                        
               }
               

        text.text=str
          }
        // Do any additional setup after loading the view.
    }
  
    
