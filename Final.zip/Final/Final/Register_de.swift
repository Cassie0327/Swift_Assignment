//
//  Register_de.swift
//  Final
//
//  Created by 蔡倩 on 12/14/19.
//  Copyright © 2019 Qian Cai. All rights reserved.
//

import UIKit

class Register_de: UITableViewController {

    @IBOutlet var dview: UITableView!
    var sub:String?
        var name:String?
        var section2:[course]=[course]()
        var section1:[course]=[course]()
        var h1=true
        var h2=true
        
        override func viewDidLoad() {
            super.viewDidLoad()
      NotificationCenter.default.addObserver(self, selector: #selector(updateList), name: NSNotification.Name(rawValue: "callForUpdate"), object: nil)
                       
           if (sub=="" || sub==nil)
           {   h1=false    }
            if (name=="" || name==nil)
            {
                h2=false
            }
            if(h1==true)
            {
                if(h2==true)
                {
                    let predicate1 = NSPredicate(format: "SELF contains %@",sub!)
                    section2 = courselist.filter { predicate1.evaluate(with: $0.subject) }
                    let predicate2 = NSPredicate(format: "SELF contains %@",name!)
                    section1 = section2.filter { predicate2.evaluate(with: $0.course_name)}
                }
                else{
                    let predicate3 = NSPredicate(format: "SELF contains %@",sub!)
                           section1 = courselist.filter { predicate3.evaluate(with: $0.subject) }
                                   }
            }
            else
           {
            if (h2==true)
            {
                let predicate4 = NSPredicate(format: "SELF contains %@",name!)
                section1 = courselist.filter { predicate4.evaluate(with: $0.course_name) }
                
            }
            else{
              section1=courselist
            
                        }
                }
            
            }
           
        

     @objc public func updateList() {
          dview.reloadData()
     }
     override func numberOfSections(in tableView: UITableView) -> Int {
         
         return 1
     }

     override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         // #warning Incomplete implementation, return the number of rows
        return section1.count
         
     }
     
     override func didReceiveMemoryWarning() {
         super.didReceiveMemoryWarning()
         // Dispose of any resources that can be recreated.
     }
     override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell1=tableView.dequeueReusableCell(withIdentifier: "regi", for: indexPath)
        var object1=""
        var object2=""
        object1=section1[indexPath.row].course_name
        object2="Course time: \(section1[indexPath.row].time)"+"\n"+"Instructor: \(section1[indexPath.row].instructor)"
        cell1.textLabel?.text=object1
        cell1.detailTextLabel?.text=object2
        return cell1
         
         
         
         
     }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
         
         guard let id=segue.identifier else{return}
         if id=="rr"
         {
             
             let row=self.dview.indexPathForSelectedRow?.row
             if let vdd2=segue.destination as? registerd
             {
                
                vdd2.label="Course name: \(section1[row!].course_name)"+"\n"+"\n"+"Course id: \(section1[row!].course_id)"+"\n"+"\n"+"Course time: \(section1[row!].time)"+"\n"+"\n"+"Instructor: \(section1[row!].instructor)"+"\n"+"\n"+"Subject: \(section1[row!].subject)"+"\n"+"\n"+"Seat/Max: \(section1[row!].seat)/40"+"\n"+"\n"+"Waitlist/Max: \(section1[row!].wait)/10"+"\n"+"\n"+"Course Description: \(section1[row!].course_description)"
                vdd2.c1=section1[row!]
                    
                 //  vc.imagename=userlist.userList[row!].Name
                 
                 
             }
         }
         
         
     }
}
