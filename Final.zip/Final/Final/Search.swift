//
//  Search.swift
//  Final
//
//  Created by 蔡倩 on 12/13/19.
//  Copyright © 2019 Qian Cai. All rights reserved.
//

import UIKit

class Search: UIViewController {

    @IBOutlet weak var subject: UITextField!
   
    @IBOutlet weak var keyword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func search(_ sender: UIButton) {
        
        
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    
       
            guard let id=segue.identifier else{return}
             if id=="search1"
               {
               
            if let vcd=segue.destination as? search_class
               {
                vcd.sub=subject.text
                vcd.name=keyword.text
              
                  
             
                   
               
        }
        }}

           
           
       

    

}
