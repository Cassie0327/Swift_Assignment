//
//  re_info.swift
//  Final
//
//  Created by 蔡倩 on 12/13/19.
//  Copyright © 2019 Qian Cai. All rights reserved.
//

import UIKit
import CoreData
class re_info: UITableViewController {
  var section1:[Int:[String]]=[:]
var section2:[Int:String]=[:]
    var section3:[Int:[course]]=[:]
    
    
    @IBOutlet var review: UITableView!
    override func viewDidLoad() {
        section2[0]="Seat"
        section2[1]="Waitlist"
        let s=UserDefaults().string(forKey: "userName") ?? ""
    
        for one in studentlist
        {
            if(one.account==s)
            {
                section3[0]=one.seat_c
                section3[1]=one.wait_c
            }
        }
        NotificationCenter.default.addObserver(self, selector: #selector(updateList), name: NSNotification.Name(rawValue: "callForUpdate"), object: nil)
        super.viewDidLoad()

    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return section3[section]?.count ?? 0
    }
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
           return section2[section]
       }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
          let cell1=tableView.dequeueReusableCell(withIdentifier: "reinfo", for: indexPath)
         var object1=""
        object1=section3[indexPath.section]![indexPath.row].course_name
        cell1.textLabel?.text=object1
          return cell1
          
          
          
          
      }
      
    
    @objc public func updateList() {
         review.reloadData()
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        guard let id=segue.identifier else{return}
        if id=="rr1"
        {
            let sec=self.review.indexPathForSelectedRow?.section
            
            let row=self.review.indexPathForSelectedRow?.row
            if let vdd3=segue.destination as? Registerdetail
            {
                vdd3.label="Course name: \(section3[sec!]![row!].course_name)"+"\n"+"\n"+"Course id: \(section3[sec!]![row!].course_id)"+"\n"+"\n"+"Course time: \(section3[sec!]![row!].time)"+"\n"+"\n"+"Instructor: \(section3[sec!]![row!].instructor)"+"\n"+"\n"+"Subject: \(section3[sec!]![row!].subject)"+"\n"+"\n"+"Seat/Max: \(section3[sec!]![row!].seat)/40"+"\n"+"\n"+"Waitlist/Max: \(section3[sec!]![row!].wait)/10"+"\n"+"\n"+"Course Description: \(section3[sec!]![row!].course_description)"
                vdd3.c1=section3[sec!]![row!]
                   
                //  vc.imagename=userlist.userList[row!].Name
                
                
            }
        }
        
        
    }
    
    

    

}
